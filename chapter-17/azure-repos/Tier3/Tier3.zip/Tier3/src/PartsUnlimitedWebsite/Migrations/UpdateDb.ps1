﻿cd "C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\Extensions\Microsoft\Entity Framework Tools\NuGet Packages\EntityFramework.6.1.3\tools"
 Import-Module .\EntityFramework.psm1